@interface RNSUIBarButtonItem : UIBarButtonItem

@property (nonatomic) BOOL menuHidden;

@end
