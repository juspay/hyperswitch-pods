//
//  StripeAPI.swift
//  hyperswitch
//
//  Created by Harshit Srivastava on 10/05/23.
//

@objc public class StripeAPI: NSObject {
    
    @objc public static var defaultPublishableKey: String? = ""
}
