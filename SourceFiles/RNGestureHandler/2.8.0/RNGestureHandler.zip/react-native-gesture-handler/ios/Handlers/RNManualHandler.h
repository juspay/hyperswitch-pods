#import "RNGestureHandler.h"

@interface RNManualGestureHandler : RNGestureHandler
@end
