import Foundation
import React

@objc(TestConnectNative)
class TestConnectNative: RCTEventEmitter {
    
    let applePayPaymentHandler = ApplePayHandler()
    public static var shared:TestConnectNative?
    
    override init() {
        super.init()
        TestConnectNative.shared = self
    }
    
    @objc
    override static func requiresMainQueueSetup() -> Bool {
        return true
    }
    
    @objc override func supportedEvents() -> [String] {
        return ["confirm"]
    }
    
    @objc func confirm(data: [String: Any]) {
        self.sendEvent(withName: "confirm", body: data)
    }
    
    @objc
    func sendMessageToNative(_ rnMessage: String) {
        print("This log is from swift: \(rnMessage)")
    }
    
    @objc
    func sendCallbackToNative(_ rnCallback: RCTResponseSenderBlock) {
        rnCallback(["A greeting from swift"])
    }
    
    @objc
    func dismissViewController (_ reactTag: NSNumber) {
        DispatchQueue.main.async {
            if let view = RNViewManager.sharedInstance.rootView {
                let reactNativeVC: UIViewController? = view.reactViewController()
                reactNativeVC?.dismiss(animated: true, completion: nil)
            }
        }
    }
    
    @objc
    func exitPaymentsheet(_ rnMessage: String) {
        var response: String?
        var error: NSError?
        let status = rnMessage.lowercased()
        if (status == "success" || status == "canceled") {
            response = status
        }
        else {
            error = NSError(domain: rnMessage, code: 0)
        }
        RNViewManager.sharedInstance.responseHandler?.didReceiveResponse(response: response, error: error)
    }
    
    @objc
    func exitCardForm(_ rnMessage: String) {
        var response: String?
        var error: NSError?
        let status = rnMessage.lowercased()
        if (status == "success" || status == "canceled") {
            response = status
        }
        else {
            error = NSError(domain: rnMessage, code: 0)
        }
        RNViewManager.sharedInstance.responseHandler?.didReceiveResponse(response: response, error: error)
    }
    
    @objc
    func launchApplePay (_ rnMessage: String, _ rnCallback: @escaping RCTResponseSenderBlock) {
        applePayPaymentHandler.startPayment(rnMessage: rnMessage, rnCallback: rnCallback)
    }
}
