#import <React/RCTBridgeModule.h>

NS_ASSUME_NONNULL_BEGIN

@interface RNCSafeAreaContext : NSObject <RCTBridgeModule>

@end

NS_ASSUME_NONNULL_END
