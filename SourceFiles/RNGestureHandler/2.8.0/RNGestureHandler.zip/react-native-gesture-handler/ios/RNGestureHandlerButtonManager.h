#import <React/RCTViewManager.h>

@interface RNGestureHandlerButtonManager : RCTViewManager

@end
