#import "RNGestureHandler.h"

@interface RNForceTouchHandler : RNGestureHandler
@end
