#ifdef RN_FABRIC_ENABLED

#import <UIKit/UIKit.h>

#import <React/RCTViewComponentView.h>

#import "RNGestureHandlerButton.h"

NS_ASSUME_NONNULL_BEGIN

@interface RNGestureHandlerButtonComponentView : RCTViewComponentView

@end

NS_ASSUME_NONNULL_END

#endif // RN_FABRIC_ENABLED
