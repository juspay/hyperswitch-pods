#import <React/RCTShadowView.h>

NS_ASSUME_NONNULL_BEGIN

@interface RNCSafeAreaShadowView : RCTShadowView

@end

NS_ASSUME_NONNULL_END
