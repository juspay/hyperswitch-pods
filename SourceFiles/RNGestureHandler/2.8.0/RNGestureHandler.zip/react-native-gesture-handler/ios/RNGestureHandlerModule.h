#import <React/RCTEventEmitter.h>
#import <React/RCTBridgeModule.h>
#import <React/RCTUIManager.h>

@interface RNGestureHandlerModule : RCTEventEmitter <RCTBridgeModule>

@end
  
